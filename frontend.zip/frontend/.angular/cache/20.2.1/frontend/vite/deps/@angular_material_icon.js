import {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
} from "./chunk-FZZ3TDNL.js";
import "./chunk-OKQXLHKH.js";
import "./chunk-7QNRB6CO.js";
import "./chunk-7PCCUSFX.js";
import "./chunk-A7PUCA7P.js";
import "./chunk-VKXVU6GJ.js";
import "./chunk-4SXL6OZJ.js";
import "./chunk-FXK7V22Z.js";
import "./chunk-7RU2CHUI.js";
import "./chunk-IHPBTLLR.js";
import "./chunk-GWPZN5JL.js";
import "./chunk-RSS3ODKE.js";
import "./chunk-WDMUDEB6.js";
export {
  ICON_REGISTRY_PROVIDER,
  ICON_REGISTRY_PROVIDER_FACTORY,
  MAT_ICON_DEFAULT_OPTIONS,
  MAT_ICON_LOCATION,
  MAT_ICON_LOCATION_FACTORY,
  MatIcon,
  MatIconModule,
  MatIconRegistry,
  getMatIconFailedToSanitizeLiteralError,
  getMatIconFailedToSanitizeUrlError,
  getMatIconNameNotFoundError,
  getMatIconNoHttpProviderError
};
