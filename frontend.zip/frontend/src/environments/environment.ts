export const environment = {
  production: false,
  backendUrl: 'http://localhost:8080',
  apiEndpoints: {
    login: '/login',
    signup: '/signup'
  }
};
