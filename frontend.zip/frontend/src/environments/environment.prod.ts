export const environment = {
  production: true,
  backendUrl: 'https://your-production-backend.com', // Update this with your production URL
  apiEndpoints: {
    login: '/login',
    signup: '/signup'
  }
};
